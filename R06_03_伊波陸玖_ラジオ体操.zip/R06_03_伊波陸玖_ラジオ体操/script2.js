  'use strict';

  window.onload = function(){
    let ms = location.search;
    if(ms == "?sound"){
      if(confirm("BGMを流してもいいですか?")){
        document.getElementById('audio').currentTime = 0;
        document.getElementById('audio').play();
        jojo();
      }
    }else{
      jojo();
    }
  };

  async function jojo(){
    scale('bucha');
      await delay(300);
    scale('rohan');
      await delay(300);
    scale('ka-zu');
      await delay(300);
    scale('dio');
      await delay(200);
    zoom('jotaro');
      await delay(300);
    scale('jairo');
      await delay(300);
    scale('si-za-');
      await delay(300);
    scale('kira');
      await delay(300);
    zoom('josefu');
      await delay(300);
    scale('suta-');
      await delay(300);
    scale('dio2');
      await delay(300);
    scale('kira-');
      await delay(300);
    scale('jotaro2');
      await delay(300);
    zoom('jonasan');
      await delay(300);
    scale('jonasan2');
      await delay(200);
    scale('joruno');
      await delay(200);
    scale('varentain2');
      await delay(700);
    
    let i;
    i = Math.floor(Math.random() * 2);
    if(i === 1){
      window.location.href = 'https://youtu.be/feSVtC1BSeQ?si=bhUGEtF_P2KYMGWJ';
    }else{
      window.location.href = 'https://youtu.be/dzQIMo-Xvyg?si=nLYII522DXY4Zjdi';
    }
  }


  async function scale(name){
    let i = 0.1;
    document.getElementById(name).style.visibility = 'visible';
    while(i < 3){
      document.getElementById(name).style.transform = `scale(${i})`;
      document.getElementById(name).style.opacity = `${140 - (i*10)*2}%`;
      i += 0.1;
      await delay(35);
    }
    document.getElementById(name).style.visibility = 'hidden';
  }

  async function zoom(name){
    document.getElementById(name).style.display = 'inline';
    for(let i = 0; i < 50; i++){
      document.getElementById(name).style.zoom =  `${i*2.2}%`;
      document.getElementById(name).style.opacity = `${170 - i*2}%`;
      await delay(25);
    }
    document.getElementById(name).style.display = 'none';
  }


  function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
